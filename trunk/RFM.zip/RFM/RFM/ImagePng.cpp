//
//  ImagePng.cpp
//  RFM
//
//  Created by Alexey Schutsky on 4/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "ImagePng.h"

#include <stdio.h>
#include <stdexcept>

using std::runtime_error;


//------------------------------------------------------------------------------
//	~ImagePng()
//------------------------------------------------------------------------------
ImagePng::~ImagePng()
{
	if( _data )
		delete _data;
}


//------------------------------------------------------------------------------
//	_pngReadFunction()
//------------------------------------------------------------------------------
void ImagePng::_pngReadFunction( png_structp png, png_byte* data, png_size_t len )
{
	FILE* f = (FILE*)png_get_io_ptr( png );
	fread( data, len, 1, f );
}


//------------------------------------------------------------------------------
//	_pngWarningFunction()
//------------------------------------------------------------------------------
void ImagePng::_pngWarningFunction( png_structp data, png_const_charp message )
{
	//throw runtime_error( message );
	printf( "PNG WARNING: %s\n", message );
}


//------------------------------------------------------------------------------
//	_pngErrorFunction()
//------------------------------------------------------------------------------
void ImagePng::_pngErrorFunction( png_structp data, png_const_charp message )
{
	throw runtime_error( message );
}

//------------------------------------------------------------------------------
//	_writeRowCallback()
//------------------------------------------------------------------------------
void ImagePng::_writeRowCallback( png_structp png, png_uint_32 row, int pass )
{
}


//------------------------------------------------------------------------------
//	save()
//------------------------------------------------------------------------------
int ImagePng::save( const char* fullPath )//, png_byte* data, png_size_t width, png_size_t height )
{
	int result = 0;
	FILE* f = 0;
	png_structp png = 0;
	png_infop info = 0;
	png_bytepp row_pointers = 0;

	try 
	{
		
		f = fopen( fullPath, "wb" );
		if( !f )
			throw runtime_error( "Can't open file" );


		//	png_structp png_write_ptr = png_create_write_struct( PNG_LIBPNG_VER_STRING, (png_voidp)user_error_ptr, user_error_fn, user_warning_fn );
		png = png_create_write_struct( PNG_LIBPNG_VER_STRING, 0, _pngErrorFunction, _pngWarningFunction );
		if( !png )
			throw runtime_error( "Can't create png_structp" );
		
		info = png_create_info_struct( png );
		if( !info )
			throw runtime_error( "Can't create info_struct" );

		png_init_io( png, f );
		
		
		png_set_write_status_fn( png, _writeRowCallback );
		
		
		png_set_IHDR( png, info, _width, _height, 8, PNG_COLOR_TYPE_RGB_ALPHA, PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT );
		
		png_set_gAMA( png, info, PNG_INFO_gAMA );
		
//		png_set_sRGB( png, info, ...);
//		png_set_sRGB_gAMA_and_cHRM( png, info, ...);
//		png_set_iCCP( png, info, ...);
//		png_set_sBIT( png, info, ...);
//		png_set_tRNS( png, info, ...);
		
//		png_set_tIME( png, info, PNG_VALID_tIME );
		
//		.....
		
		/* *** output transformations ***
		PNG_TRANSFORM_IDENTITY				- No transformation
		PNG_TRANSFORM_PACKING				- Pack 1, 2 and 4-bit samples
		PNG_TRANSFORM_PACKSWAP				- Change order of packed pixels to LSB first
		PNG_TRANSFORM_INVERT_MONO			- Invert monochrome images
		PNG_TRANSFORM_SHIFT					- Normalize pixels to the sBIT depth
		PNG_TRANSFORM_BGR					- Flip RGB to BGR, RGBA to BGRA
		PNG_TRANSFORM_SWAP_ALPHA			- Flip RGBA to ARGB or GA to AG
		PNG_TRANSFORM_INVERT_ALPHA			- Change alpha from opacity to transparency
		PNG_TRANSFORM_SWAP_ENDIAN			- Byte-swap 16-bit samples
		PNG_TRANSFORM_STRIP_FILLER			- Strip out filler bytes (deprecated).
		PNG_TRANSFORM_STRIP_FILLER_BEFORE	- Strip out leading filler bytes
		PNG_TRANSFORM_STRIP_FILLER_AFTER	- Strip out trailing filler bytes
		 */
		int transforms = PNG_TRANSFORM_INVERT_ALPHA; // -?
		

		// low-level
		
		png_write_info( png, info );
		
		//png_set_bgr( png );
		
		// выделяем память, для указателей на каждую строку
		row_pointers = new png_byte * [_height];
		
		// сопоставляем массив указателей на строчки, с выделенными в памяти (res)
		// т.к. изображение перевернутое, то указатели идут снизу вверх
		png_uint_32 row_bytes = _width * 4;

		for( png_uint_32 i = 0; i < _height; i++ )
			row_pointers[i] = &_data[i * row_bytes];
		//			row_pointers[height - i - 1] = data + i * row_bytes;

		png_write_image( png, row_pointers );
		
		
		png_write_end( png, info );
		
		//* *** hi-level
//		png_set_rows(); -??
		
//		png_write_png( png, info, transforms, NULL );
		
		
	}
	catch( runtime_error& e )
	{
		printf( "ERROR: %s\n", e.what() );
		result = -1;
	}
	
	
	// clenup
	if( row_pointers )
		delete[] row_pointers;

	if( png )
		png_destroy_write_struct( &png, &info );
		
	if( f )
		fclose( f );
	
	return result;
}



void ImagePng::setSize( unsigned long imgWidth, unsigned long imgHeight )
{
	_width = imgWidth;
	_height = imgHeight;
	
	if( _data )
		delete[] _data;
	
	unsigned long memSize = _width * _height * 4 * sizeof( png_byte ); ;
	_data = new png_byte[ memSize ];
	memset( _data, 0, memSize );
}


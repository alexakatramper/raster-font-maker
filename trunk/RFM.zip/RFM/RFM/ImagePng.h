//
//  ImagePng.h
//  RFM
//
//  Created by Alexey Schutsky on 4/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef RFM_ImagePng_h
#define RFM_ImagePng_h

#include "png.h"

class ImagePng
{
public:
	ImagePng() :_width(0), _height(0), _data(0){}
	~ImagePng();
	
	png_uint_32 width()		{ return _width; }
	png_uint_32 height()	{ return _height; }
	png_byte*	pixelData()	{ return _data; }
	
	void setSize( unsigned long imgWidth, unsigned long imgHeight );
	
	int save( const char* fullPath );//, png_byte* data, png_size_t width, png_size_t height );


	static void _pngReadFunction( png_structp png, png_byte* data, png_size_t len );
	static void _pngWarningFunction( png_structp data, png_const_charp message );
	static void _pngErrorFunction( png_structp data, png_const_charp message );
	static void _writeRowCallback( png_structp png, png_uint_32 row, int pass );
	
private:
	unsigned long	_width;
	unsigned long	_height;
	png_byte*		_data;
};

#endif

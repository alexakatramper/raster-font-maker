//
//  RFMAppDelegate.m
//  RFM
//
//  Created by Alexey Schutsky on 4/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
//======================================

#import <CoreFoundation/CoreFoundation.h>
#import <ApplicationServices/ApplicationServices.h>

#import "ImagePng.h"
#import "FontDrawer.h"

#import "RFMAppDelegate.h"


FontDrawer* drawer = 0;



NSImage* createImage( png_byte* data,	//const Pixel32 *pxl,
					 uint16 width,
					 uint16 height )
{
	
	CGDataProviderRef dataProvider = CGDataProviderCreateWithData( NULL, data, sizeof( png_byte ) * 4 * width * height, NULL );
	//CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
	CGColorSpaceRef colorSpace = CGColorSpaceCreateWithName( kCGColorSpaceGenericRGB );
	CGImageRef imageRef = CGImageCreate( width, height, 8, 32, width * 4, colorSpace, 0, dataProvider, 0, NO, kCGRenderingIntentDefault);
	
	NSImage* theImage = [[NSImage alloc] initWithCGImage:imageRef size:NSZeroSize];
	
	/*
	 NSSize theSize;
	 theSize.width = width;
	 theSize.height = height;
	 NSImage* theImage = [[NSImage alloc] initWithSize:theSize];
	 */
	return theImage;
}



@implementation RFMAppDelegate

@synthesize window = _window;
@synthesize preview = _preview;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
	
//	NSString* fileName = [[NSBundle mainBundle] pathForResource:@"ERSLogo" ofType:@"jpg"];
//	NSImage* theImage = [[NSImage alloc] initWithContentsOfFile:fileName];
	
	[_preview setImageAlignment:NSImageAlignCenter];
	[_preview setImageScaling:NSImageScaleProportionallyDown];
	
//	[_preview setObjectValue:theImage];
	
	
	drawer = new FontDrawer();
	drawer->init();
	
	const char* charFileName = [[[NSBundle mainBundle] pathForResource:@"charlist" ofType:@"txt"] fileSystemRepresentation];

	drawer->loadCharList( charFileName );
	
	// Open up a font file
	
	const char* fontFileName = [[[NSBundle mainBundle] pathForResource:@"SquareAntiqua" ofType:@"ttf"] fileSystemRepresentation];
//	drawer->loadFont( fontFileName );
	drawer->loadFont( "/Library/Fonts/Arial Unicode.ttf" );
	drawer->setFontSize( 48 );
	drawer->setOutlineWidth( 3.0f );
	
	PixelData32 baseColor( 255, 255, 255 );
	PixelData32 outlineColor( 0, 0, 0 );
	
	drawer->setBaseColor( baseColor );
	drawer->setOutlineColor( outlineColor );
	
	drawer->updateImage();
	
	
	
	NSArray*  paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString* documentsDirectory = [paths objectAtIndex: 0];
	
	const char* targetFileName = [[documentsDirectory stringByAppendingPathComponent: @"output.png"] fileSystemRepresentation];
	NSLog( @"Result path: %s", targetFileName );
	
	drawer->saveImage( targetFileName );
	
	[self updatePreview];
}


- (void)updatePreview
{
	ImagePng* png = drawer->getImage();
	if( png )
	{
		NSImage* theImage = createImage( png->pixelData(), png->width(), png->height() );
		
		[_preview setObjectValue:theImage];
	}
}


- (IBAction)setFontColor:(id)sender
{
	NSColor *newColor = [sender color];
	
	CGFloat fRed;
	CGFloat fGreen;
	CGFloat fBlue;
	CGFloat fAlpha;
	
	[newColor getRed:&fRed green:&fGreen blue:&fBlue alpha:&fAlpha];
	
	PixelData32 color;
	color.r = 255 * fRed;
	color.g = 255 * fGreen;
	color.b = 255 * fBlue;
	color.a = 255 * fAlpha;

	drawer->setBaseColor( color );
	drawer->updateImage();
	
	[self updatePreview];
}


- (IBAction)setOutlineColor:(id)sender
{
	NSColor *newColor = [sender color];
	
	CGFloat fRed;
	CGFloat fGreen;
	CGFloat fBlue;
	CGFloat fAlpha;
	
	[newColor getRed:&fRed green:&fGreen blue:&fBlue alpha:&fAlpha];
	
	PixelData32 color;
	color.r = 255 * fRed;
	color.g = 255 * fGreen;
	color.b = 255 * fBlue;
	color.a = 255 * fAlpha;
	
	drawer->setOutlineColor( color );
	drawer->updateImage();
	
	[self updatePreview];
}

@end



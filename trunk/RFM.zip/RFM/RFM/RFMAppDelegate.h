//
//  RFMAppDelegate.h
//  RFM
//
//  Created by Alexey Schutsky on 4/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface RFMAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;
@property (assign) IBOutlet NSImageCell *preview;

- (IBAction)setFontColor:(id)sender;
- (IBAction)setOutlineColor:(id)sender;

- (void)updatePreview;
@end


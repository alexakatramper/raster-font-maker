//
//  FontDrawer.h
//  RFM
//
//  Created by Alexey Schutsky on 4/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef RFM_FontDrawer_h
#define RFM_FontDrawer_h

#include <string>
#include <map>

using std::string;
using std::map;

#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_STROKER_H

struct GlyphInfo
{
	GlyphInfo(): xPos(0), yPos(0), gIndex(0) { /*glyph = 0;*/ }
	GlyphInfo( const GlyphInfo& gi ): xPos(gi.xPos), yPos(gi.yPos), gIndex(gi.gIndex) { /*FT_Glyph_Copy( gi.glyph, &glyph );*/ }
	~GlyphInfo() { /*if( glyph ) FT_Done_Glyph( glyph );*/ }
	
	//FT_Glyph	glyph;	// original glyph info
	FT_UInt		gIndex;
	FT_Pos		xPos;	// calculated x position on image
	FT_Pos		yPos;	// calculated y position on image
};

typedef map<short,GlyphInfo> GlyphMap;	//wchar_t is 32-bit in MacOS ??

class ImagePng;

struct PixelData32
{
	PixelData32(): r(0), g(0), b(0), a(255) {}
	PixelData32( unsigned char r_, unsigned char g_, unsigned char b_, unsigned char a_ = 255 ) : r(r_), g(g_), b(b_), a(a_) {}
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char a;
};


class FontDrawer
{
public:
	FontDrawer();
	~FontDrawer();
	
	int init();

	void updateImage();
	void createImage_old(); // deprecated...
	
	ImagePng* getImage() { return _image; }
	
	void loadFont( const string& fullPath );

	void saveImage( const string& fullPath );
	
	void setFontSize( int n ) { _fontSize = n; }
	void setOutlineWidth( float v ) { _outlineWidth = v; }

	void setBaseColor( PixelData32& color ) { _baseColor.r = color.r; _baseColor.g = color.g; _baseColor.b = color.b; _baseColor.a = color.a; }
	void setOutlineColor( PixelData32& color ) { _outlineColor.r = color.r; _outlineColor.g = color.g; _outlineColor.b = color.b; _outlineColor.a = color.a; }
	
	int loadCharList( const string& fileName );
	
protected:
	FT_Library	_library;
	FT_Face		_face;

	string		_fontName;

	ImagePng*	_image;
	
	int			_fontSize;
	float		_outlineWidth;
	PixelData32	_baseColor;
	PixelData32	_outlineColor;
	
	GlyphMap	_glypMap;
};

#endif
